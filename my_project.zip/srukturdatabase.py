# Data awal
Nilai = [78, 85, 90, 85]
Mahasiswa = {"nama": "Nadia", "kelas": "IF-A"}
Koordinat = (5, 8)
angka = {2, 4, 4, 6, 8}


# Tampilkan nilai pertama dari list 
print("Nilai pertama dari list:", Nilai[0])


# Tambahkan nilai 95 ke list dan tampilkan list terbaru
Nilai.append(95)
print("List terbaru:", Nilai)


# Tampilkan nama mahasiswa dri dictionary
print("Nama mahasiswa:", Mahasiswa["nama"])

# Tampilkan koordinat pertama dari tuple
print("Koordinat pertama:", Koordinat[0])


