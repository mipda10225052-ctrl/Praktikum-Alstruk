# data awal
Nama = "fajar"
Umur = 19
Berat =54,5
Terdaftar ='true'

# Tampilkan  semua nilai variabel
print("Nama:", Nama)  
print("Umur:", Umur)  
print("Berat:", Berat)  
print("Terdaftar:", Terdaftar)

# Tampilkan tipe data setiap variabel
print("Tipe data nama:", type(Nama))
print("Tipe data umur:", type(Umur))
print("Tipe data berat:", type(Berat))
print("Tipe data terdaftar:", type(Terdaftar))

# Ubah nilai umur menjadi 20
Umur = 20
print("Umur baru:", Umur)
print("Tipe data umur baru:", type(Umur))










