# Buat variabel nilai dan kehadiran (data awal: nilai = 82, kehadiran =90)
Nilai = 82 
Kehadiran = 90

print("---Hasil dengan Data Awal (Nilai=82, Kehadiran=90) ---")

# Gunakan operator >= untuk memeriksa masing-masing  syarat 
syarat_nilai = Nilai >= 75
syarat_kehadiran = Kehadiran>= 80

print(f"Apakah nilai memenuhi syarat? {syarat_nilai}")
print("syarat Kehadiran (>= 80):", syarat_kehadiran)

# Gunakan operator  and untuk menemukan apakah mahasiswa memenuhi kedua syarat
Kelulusan_and = (Nilai >= 75) and (Kehadiran >= 80)
print("Apakah memenuhi kedua syarat (and)?", Kelulusan_and)

print("-" * 40)

# Ubah nilai menjadi 70, amati perubahan hasil
nilai =70
print("--- Hasil setelah Nilai diubah menjadi 70 ---")

syarat_nilai = nilai  >= 75
syarat_kehadiran = Kehadiran >= 80

print(f"Apakah Nilai memenuhi syarat? {syarat_nilai}")
print(f"Apakah kehadiran memenuhi syarat? {syarat_kehadiran}")

lulus_and = syarat_nilai and syarat_kehadiran
print(f"status kelulusan (menggunakan and): {lulus_and}")




