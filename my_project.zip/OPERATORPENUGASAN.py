# Langkah 1: Simpan poin awal
poin = 100
print(f"Langkah 1 (Nilai awal) : {poin}")

# Langkah 2: Tambahkan 25 poin
poin += 25
print(f"Langkah 2 (poin += 25) : {poin}")

# Langkah 3: Kurangi 10 poin
poin -= 10
print(f"Langkah 3 (poin -= 10) : {poin}")

# Langkah 4: Kalikan poin dengan 2
poin *= 2
print(f"Langkah 4 (poin *= 2)  : {poin}")

# Langkah 5: Bagi poin dengan 2
# Menggunakan /= menghasilkan tipe data float (desimal)
poin /= 2
print(f"Langkah 5 (poin /= 2)  : {int(poin)}") # Diubah ke int agar tampil 115

