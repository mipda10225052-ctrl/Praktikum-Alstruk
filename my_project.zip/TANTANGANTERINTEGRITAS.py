# === UJI COBA 1 (Kombinasi Nilai 1 - Lulus) ===
nama_1 = "Andi Prasetyo"
nilai_tugas_1 = 80
nilai_ujian_1 = 80

# Hitung rata-rata
rata_rata_1 = (nilai_tugas_1 + nilai_ujian_1) / 2
# Status kelulusan (minimal 75)
status_lulus_1 = rata_rata_1 >= 75

print("=== REKAP NILAI MAHASISWA (UJI 1) ===")
print("Nama Mahasiswa :", nama_1)
print("Nilai Tugas    :", nilai_tugas_1)
print("Nilai Ujian    :", nilai_ujian_1)
print("Rata-rata      :", rata_rata_1)
print("Status Lulus   :", status_lulus_1)

print("\n" + "="*40 + "\n")

# === UJI COBA 2 (Kombinasi Nilai 2 - Tidak Lulus) ===
nama_2 = "Siti Rahma"
nilai_tugas_2 = 70
nilai_ujian_2 = 65

# Hitung rata-rata
rata_rata_2 = (nilai_tugas_2 + nilai_ujian_2) / 2
# Status kelulusan (minimal 75)
status_lulus_2 = rata_rata_2 >= 75

print("=== REKAP NILAI MAHASISWA (UJI 2) ===")
print("Nama Mahasiswa :", nama_2)
print("Nilai Tugas    :", nilai_tugas_2)
print("Nilai Ujian    :", nilai_ujian_2)
print("Rata-rata      :", rata_rata_2)
print("Status Lulus   :", status_lulus_2)







