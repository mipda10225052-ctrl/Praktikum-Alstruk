# Buat variabel: harga Rp 12.500, jumlah 4 buku)
harga = 12500
jumlah =4


# Hitung total harga
total_harga = harga * jumlah


# Hitung sisa pembagian total harga dengan 2.000 menggunakan operator %
Sisa_pembagian = total_harga % 2000


# Hitung harga setelah diskon Rp 5.000
Harga_setelah_diskon = total_harga - 5000

# Taampilkan hasil setiap perhitungan denngan label yang jelas
print("Total Harga:", total_harga)  
print("Sisa pembagian dengan 2000:", 'sisa_pembagian')  
print("Harga setelah diskonRp 5000:", 'Harga_setelah_diskon')





